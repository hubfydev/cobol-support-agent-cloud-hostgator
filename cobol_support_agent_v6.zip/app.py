# app.py - Versão 6
print('COBOL Support Agent v6')
