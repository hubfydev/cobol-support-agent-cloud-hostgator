class OllamaClient:
    pass
